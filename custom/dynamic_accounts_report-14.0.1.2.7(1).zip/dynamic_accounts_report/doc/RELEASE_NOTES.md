## Module <dynamic_accounts_report>

#### 03.05.2021
#### Version 14.0.1.0.0
#### ADD
- Initial commit for Odoo 14 dynamic financial reports

#### 21.05.2021
#### Version 14.0.1.1.1
#### UPDT
- Updated Style and Currency Format

#### 27.05.2021
#### Version 14.0.1.2.1
#### UPDT
- Ageing Report.


#### 28.06.2021
#### Version 14.0.1.2.2
#### UPDT
- Updated

#### 10.08.2021
#### Version 14.0.1.2.3
#### UPDT
- Style Issue Updated


#### 20.12.2021
#### Version 14.0.1.2.4
#### UPDT
- Translation issue and Calendar format issue

#### 15.01.2022
#### Version 14.0.1.2.5
#### UPDT
- Arabic Translation added

#### 01.02.2022
#### Version 14.0.1.2.6
#### UPDT AND BUGFIX
- Multi-company and Translation Update and Bugfix

#### 16.04.2022
#### Version 14.0.1.2.7
#### UPDT AND BUGFIX
- Loading Issue and orderby date

#### 27.04.2023
#### Version 14.0.1.2.7
#### UPDT AND BUGFIX
- Update and Bugfix in General Ledger